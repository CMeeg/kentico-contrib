CREATE TYPE [dbo].[Type_CMS_StringTable] AS TABLE(
	[Value] [nvarchar](450) NULL
)
GO
